from django.contrib import admin
from chkbal.models import UserProfile,account

admin.site.register(UserProfile)
admin.site.register(account)
